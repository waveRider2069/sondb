$(document).ready(function() {
    // $("input.submit").click(function() {
    //     // if ($("input.username").val() == "sonovaRD" && $("input.password").val() == "abc123") {
    //     //     $("form[name=login]").css({"display":"none"});
    //     //     $("div.welcome").css({"display":"block"});
    //     //     $("div.menu a").addClass("success");
    //     //     $("a.consult").prop("href", "html/consult_1.html");
    //     //     $("a.subject").prop("href", "html/subject_new.html");
    //     //     $("a.projects").prop("href", "html/projects_overview.html");
    //     // } else {
    //     //     alert("invalid username or password!");
    //     // }
    // })
});